1. Install necessary modules by running following command
	pip install -r requirements.txt

2. 'langchain_crashcourse.ipynb' contains the notebook in the video tutorial on codebasics YouTube channel

3. 'RestaurantNameGenerator' folder contain the streamlit app that generates restaurant name based on the cuisine and also the food items in that restaurant.
