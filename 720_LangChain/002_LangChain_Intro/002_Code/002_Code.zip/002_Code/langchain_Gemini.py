## Integrate LangChain with Gemini from LangChain OpenAI API

#from langchain.llms import OpenAI
#import langchain
import google.generativeai as genai
from langchain_google_genai import ChatGoogleGenerativeAI

import streamlit as st
import os
#from constants import openai_key
#os.environ["OPENAI_API_KEY"]=openai_key
from dotenv import load_dotenv
load_dotenv() ## loading all the environment variables

## OPENAI LLMS
#llm=OpenAI(openai_api_key=os.environ["OPEN_API_KEY"], temperature=0.8)
# We still use Ggoogle GenerativeAI to configure gemini.
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
llm = ChatGoogleGenerativeAI (model ='gemini-pro', temperatire=0.9)

# streamlit framework
#st.title('Langchain Demo With OPENAI API')
st.title('Langchain Demo with Gemini-pro')
input_text=st.text_input("Search the topic u want")

if input_text:
    #print ('llm.predict(text):', llm.predict(text))
    # predict is depreciated. use 'invoke' instead
    #st.write(llm(input_text))
    response = llm.invoke(input_text)
    print('response.content:', response.content)
    st.write(response.content)
