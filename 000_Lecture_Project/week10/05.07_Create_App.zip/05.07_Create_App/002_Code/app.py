## Conversational Q&A Chatbot
import streamlit as st

from langchain.schema import HumanMessage,SystemMessage,AIMessage
#from langchain.chat_models import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI


# Load all the environment variabels defined in .env:
# 1. GOOGLE_API_KEY and 
# 2. HUGGINGFACEHUB_API_KEY
from dotenv import load_dotenv
load_dotenv()

# Get the GOOGLE_API_KEY from environment variable 'GOOGLE_API_KEY'
import os
GOOGLE_API_KEY = os.environ['GOOGLE_API_KEY']

def get_google_chat_response (question):
    llm = ChatGoogleGenerativeAI (model="gemini-pro", google_api_key=GOOGLE_API_KEY,temperature=0.5)
    response = llm.predict(question)
    return response

## Instialize streamlit app
st.set_page_config (page_title="Q&A Demo")
st.header("LangChain Application")

input = st.text_input("Input: ", key = "input")
response = get_google_chat_response (input)

submit = st.button("Ask the quesiton")

## If ask button is clicked
if submit :
    st.subheader("The Response is")
    st.write (response)
