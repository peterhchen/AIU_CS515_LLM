# openai_key=""
GOOGLE_API_KEY = "AIzaSyBcws3Gv_g0S26lzDM5n_fQ3h3gEBOoDYw"