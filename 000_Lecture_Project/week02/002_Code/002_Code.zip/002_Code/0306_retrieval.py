import os
#!conda install -y streamlit
import streamlit as st
import pickle
import numpy as np
import time
#!conda install -y langchain
import langchain
#from langchain import OpenAI
from langchain.llms import OpenAI
from langchain.chains import RetrievalQAWithSourcesChain
from langchain.chains.qa_with_sources.loading import load_qa_with_sources_chain
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import UnstructuredURLLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS

#load openAI api key
# os.environ['OPENAI_API_KEY'] = 'your openapi key here'
import os
import sys
sys.path.append("/home/peter/")
from secret_key import *
os.environ['OPENAI_API_KEY'] = openapi_key
print ('import openapi_key from /home/peter/secret_key.py')
print()
print('openapikey:', openapi_key) # openapikey: sk-i...

llm = OpenAI(temperature=0.9, max_tokens=500) 
# (1) Load Data
loaders = UnstructuredURLLoader(urls=[
    "https://www.moneycontrol.com/news/business/markets/wall-street-rises-as-tesla-soars-on-ai-optimism-11351111.html",
    "https://www.moneycontrol.com/news/business/tata-motors-launches-punch-icng-price-starts-at-rs-7-1-lakh-11098751.html"
])
data = loaders.load() 
print('len(data):', len(data))

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)
#(2) Split data to craete chunks.
# As data is of type documents we can directly use split_documents over split_text in order to get the chunks.
docs = text_splitter.split_documents(data)
print('len(docs):', len(docs))
print('docs[0]:', docs[0])

# (3) Create embeddings for these chunks and save them to FAISS index 
# Create the embeddings of the chunks using openAIEmbeddings
openAI_sim = False
if openAI_sim is True:
    embeddings = OpenAIEmbeddings()
else:
    from langchain.embeddings import LlamaCppEmbeddings
    # Download llama model file: https://huggingface.co/TheBloke/Hermes-Trismegistus-Mistral-7B-GGUF
    llama_model_path = '.'
    print('LlamaCppEmbeddings...')
    embeddings = LlamaCppEmbeddings(model_path=llama_model_path)

# Pass the documents and embeddings inorder to create FAISS vector index
print('FAISS.from_documents...')
vectorindex_openai = FAISS.from_documents(docs, embeddings)
# Storing vector index create in local
file_path="vector_index.pkl"
with open(file_path, "wb") as f:
    pickle.dump(vectorindex_openai, f)

if os.path.exists(file_path):
    with open(file_path, "rb") as f:
        vectorIndex = pickle.load(f)

# (4) Retrieve Similar embeddings for a give question 
# and call LLM to retrive final answer
chain = RetrievalQAWithSourcesChain.from_llm(llm=llm, retriever=vectorIndex.as_retriever())
print('chain:', chain)

query = "what is the price of Tiago iCNG?"
# query = "what are the main features of punch iCNG?"

langchain.debug=True

chain({"question": query}, return_only_outputs=True)