from langchain.llms import GooglePalm

# (1) Google Palm LLM & API key setup
#api_key = 'AIzaSyDlXYnP2xNNa0DNa7dPN89u2L4IuAchEg4'
#llm = GooglePalm(google_api_key=api_key, temperature=0.2)

print('(1) Google Palm LLM & API key setup...')
import os
import sys
sys.path.append(os.path.abspath("/home/peter/"))
from secret_key import *
print('googleapi_key:', googleapi_key)

# (3) Test Google's llm()
from langchain.llms import GooglePalm
llm = GooglePalm(google_api_key=googleapi_key, temperature=0.2)
print('llm:', llm) # llm: GooglePalm
print()
q1 = "write a poem on my love for dosa"
a1 = llm(q1)
print('q1:', q1)
print('a1:')
print(a1)

# (4) Connect with database ands ask some basic quesiotns
from langchain.utilities import SQLDatabase
db_user = "root"
db_password = "root"
db_host = "localhost"
db_name = "atliq_tshirts"
# URL syntax: "mysql+pymysql://root:root@localhost/{db_name}"
print()
url_name = "mysql+pymysql://"+db_user+":"+ db_password+"@"+db_host + "/" + db_name
print('url_name = "mysql+pymysql://"+db_user+":"+ db_password+"@"+db_host + "/" + db_name:')
print('url_name:', url_name)
#db = SQLDatabase.from_uri(f"mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}",sample_rows_in_table_info=3)
print("db = SQLDatabase.from_uri(url_name,sample_rows_in_table_info=3) ...")
db = SQLDatabase.from_uri(url_name,sample_rows_in_table_info=3)
print()
print("db.table_info:")
print(db.table_info)

# The langchain from experimental modules from netural language to SQL datanase has many errors.
# They cannot handle the start/stop date.

# (7) We change to few shots Learning to fix the error.
# We will use few shot learning to fix error translations (start/stop date etc.) we saw so far. 
qns1 = "205"; qns2 = "321"; qns3 = "17771"; qns4 = "25993"; qns5 = "79"
few_shots = [
    {'Question' : "How many t-shirts do we have left for Nike in XS size and white color?",
     'SQLQuery' : "SELECT sum(stock_quantity) FROM t_shirts WHERE brand = 'Nike' AND color = 'White' AND size = 'XS'",
     'SQLResult': "Result of the SQL query",
     'Answer' : qns1},
    {'Question': "How much is the total price of the inventory for all S-size t-shirts?",
     'SQLQuery':"SELECT SUM(price*stock_quantity) FROM t_shirts WHERE size = 'S'",
     'SQLResult': "Result of the SQL query",
     'Answer': qns2},
    {'Question': "If we have to sell all the Levi’s T-shirts today with discounts applied. How much revenue  our store will generate (post discounts)?" ,
     'SQLQuery' : """SELECT sum(a.total_amount * ((100-COALESCE(discounts.pct_discount,0))/100)) as total_revenue from
(select sum(price*stock_quantity) as total_amount, t_shirt_id from t_shirts where brand = 'Levi'
group by t_shirt_id) a left join discounts on a.t_shirt_id = discounts.t_shirt_id
 """,
     'SQLResult': "Result of the SQL query",
     'Answer': qns3} ,
     {'Question' : "If we have to sell all the Levi’s T-shirts today. How much revenue our store will generate without discount?" ,
      'SQLQuery': "SELECT SUM(price * stock_quantity) FROM t_shirts WHERE brand = 'Levi'",
      'SQLResult': "Result of the SQL query",
      'Answer' : qns4},
    {'Question': "How many white color Levi's shirt I have?",
     'SQLQuery' : "SELECT sum(stock_quantity) FROM t_shirts WHERE brand = 'Levi' AND color = 'White'",
     'SQLResult': "Result of the SQL query",
     'Answer' : qns5
     }
]

# (8) Creating Semantic Similarity Based example selector
# create embedding on the few_shots
# Store the embeddings in Chroma DB
# Retrieve the the top most Semantically close example from the vector store
print()
print('**********************************************')
print('(8) Creating Semantic Similarity Based example selector:')
from langchain.embeddings import HuggingFaceEmbeddings


embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
e = embeddings.embed_query ("How many white color Levi's shirt I have?")
print('len(e):', len(e))  # 384
print('e[:5]:', e[:5]) 
# e[:5]: [0.0036103627644479275, 0.07093449681997299, -0.002751036314293742, 0.0009241114603355527, 0.05407031252980232]

#to_vectorize = [" ".join(example.values()) for example in few_shots]
print('**********************************************')
print('[example.values() for example in few_shots]:')
print([example.values() for example in few_shots])
to_vectorize = []
str1 = ""
for example in few_shots:
    #print('exmaple:')
    #print(example)
    #print('exmaple.values():')
    #print(example.values())
    str1 = " ".join(str(x) for x in example.values()) 
    print('str1:')
    print(str1)
    to_vectorize.append(str1)

print('**********************************************')
print('to_evctorize[0]:')
print(to_vectorize[0])
print('**********************************************')
print('to_evctorize:')
print(to_vectorize)

# (9) Store vetor into embedding.
from langchain.vectorstores import Chroma
print()
print("*********************")
print('(9) Use Chroma to store vector into embedding Database...')
print('  (9.1) vector data is store into vector database as FuggingFace embedding by Chroma')
print('  (9.2) Entire few shots are store as meta data.')
# (9.1) vector data is store into vector database as FuggingFace embedding by Chroma.
# (9.2) Entire few shots are store as meta data.
vectorstore = Chroma.from_texts(to_vectorize, embedding=embeddings, metadatas=few_shots)
print('vectorstore:') 
print(vectorstore) 

# (9.3) Vector Database are stored and grouped in Semantic Similarity
print('  (9.3) Vector Database are stored and grouped in Semantic Similarity')
from langchain.prompts import SemanticSimilarityExampleSelector
example_selector = SemanticSimilarityExampleSelector(
    vectorstore=vectorstore,
    k=2, # k = 1, 2, 3 (We only looks for 2 similar answers)
)

# (10) Look for Similar Answer
print()
print("*********************")
print('(10) Look for Similar Answer...')
sim_ans = example_selector.select_examples({"Question": "How many Adidas T shirts I have left in my store?"})
print ('sim_ans:', sim_ans)

# (11) my sql based instruction prompt
print()
print("*********************")
print('(11) MySQL based instruction prompt...')
mysql_prompt = """You are a MySQL expert. Given an input question, first create a syntactically correct MySQL query to run, then look at the results of the query and return the answer to the input question.
Unless the user specifies in the question a specific number of examples to obtain, query for at most {top_k} results using the LIMIT clause as per MySQL. You can order the results to return the most informative data in the database.
Never query for all columns from a table. You must query only the columns that are needed to answer the question. Wrap each column name in backticks (`) to denote them as delimited identifiers.
Pay attention to use only the column names you can see in the tables below. Be careful to not query for columns that do not exist. Also, pay attention to which column is in which table.
Pay attention to use CURDATE() function to get the current date, if the question involves "today".

Use the following format:

Question: Question here
SQLQuery: Query to run with no pre-amble
SQLResult: Result of the SQLQuery
Answer: Final answer here

No pre-amble.
"""

from langchain.chains.sql_database.prompt import PROMPT_SUFFIX, _mysql_prompt
print()
print("*********************")
print("(11.1) We define our mysql_prompt:")
print(mysql_prompt)
print()
print("(11.2) PROMPT_SUFFIX:")
print(PROMPT_SUFFIX)  # {table_info} Question: {input}
print("*********************")
print("(11.3) sql_database: _mysql_prompt:")
print(_mysql_prompt)

# (12) Setting up PromptTemplete using input variables
print()
print("*********************")
print('(12) Setting up PromptTemplete using input variables...')
from langchain.prompts.prompt import PromptTemplate

example_prompt = PromptTemplate(
    input_variables=["Question", "SQLQuery", "SQLResult","Answer",],
    template="\nQuestion: {Question}\nSQLQuery: {SQLQuery}\nSQLResult: {SQLResult}\nAnswer: {Answer}",
)
print('example_prompt:')
print(example_prompt)

# (13) Few Shot prompt
print()
print("*********************")
print('(13) Few Shot prompt...')
from langchain.prompts import FewShotPromptTemplate
few_shot_prompt = FewShotPromptTemplate(
    example_selector=example_selector,
    example_prompt=example_prompt,
    prefix=mysql_prompt,
    suffix=PROMPT_SUFFIX,
    input_variables=["input", "table_info", "top_k"], #These variables are used in the prefix and suffix
)

print('few_shot_prompt:')
print(few_shot_prompt)

print()
print("*********************")
print('(14) SQLDatabase Chain...')
from langchain_experimental.sql import SQLDatabaseChain
new_chain = SQLDatabaseChain.from_llm(llm, db, verbose=True, prompt=few_shot_prompt)

# (15) Test New Chain 
# Now this is working ok. Previously for this same question it was giving wrong answer 
# because it did not use SUM clause around stock_quantity column
print()
print("************")
print("(15) Test New Chain ...")
print("Previously for this same question it was giving wrong answer ")
print("The answer is correct...")
new_chain("How many white color Levi's shirt I have?")
new_chain("How much is the price of the inventory for all small size t-shirts?")
new_chain("If we have to sell all the Nike’s T-shirts today with discounts applied. How much revenue  our store will generate (post discounts)?")
new_chain("If we have to sell all the Van Heuson T-shirts today with discounts applied. How much revenue  our store will generate (post discounts)?")
new_chain.run('How much revenue  our store will generate by selling all Van Heuson TShirts without discount?')