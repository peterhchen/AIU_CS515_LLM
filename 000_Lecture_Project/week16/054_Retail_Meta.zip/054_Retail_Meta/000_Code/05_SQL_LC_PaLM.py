# (1) Google Palm LLM & API key setup
print('(1) Google Palm LLM & API key setup...')
import os
import sys
sys.path.append(os.path.abspath("/home/peter/"))
from secret_key import *
print('googleapi_key:', googleapi_key)
from langchain.llms import GooglePalm
llm = GooglePalm(google_api_key=googleapi_key, temperature=0.2)
print('llm:', llm) # llm: GooglePalm
print()

# (2) Connect with database and ask some basic questions
print('(2) Connect with database and ask some basic questions ...')

from langchain.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain

db_user = "root"
db_password = "root"
db_host = "localhost"
db_name = "atliq_tshirts"

db = SQLDatabase.from_uri(f"mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}",sample_rows_in_table_info=3)
print('db.table_info:')
print(db.table_info)

