import sqlite3

## Connectt to SQlite
connection=sqlite3.connect("student.db")

# Create a cursor object to insert record,create table

cursor=connection.cursor()

## create the table
table_info="""
Create table STUDENT(NAME VARCHAR(25),CLASS VARCHAR(25),
SECTION VARCHAR(25),MARKS INT);

"""
cursor.execute(table_info)

## Insert Some more records

cursor.execute('''Insert Into STUDENT values('Jonathan Chen', 'Deep Learning', 'Fall, 2023', 95)''')
cursor.execute('''Insert Into STUDENT values('Senken Ma', 'Deep Learning', 'Fall 2023', 95)''')
cursor.execute('''Insert Into STUDENT values('Jason Chen', 'Deep Learning', 'Fall 2023', 85)''')
cursor.execute('''Insert Into STUDENT values('Jasmine Chen', 'Full Stack Devloper', 'Fall 2024', 90)''')
cursor.execute('''Insert Into STUDENT values('Jessica Chen', 'Full Stack Develper', 'Fall 2024', 80)''')
cursor.execute('''Insert Into STUDENT values('Jonathan Chen', 'Data Science', 'Summer, 2022', 97)''')
cursor.execute('''Insert Into STUDENT values('Senken Ma', 'Data Science', 'Summer 2022', 95)''')
cursor.execute('''Insert Into STUDENT values('Jason Chen', 'Computer Network', '2022 2022', 90)''')
cursor.execute('''Insert Into STUDENT values('Jasmine Chen', 'Operating System', 'Fall 2022', 85)''')
cursor.execute('''Insert Into STUDENT values('Jessica Chen', 'Machine Learning', 'Fall 2023', 80)''')

## Disspaly ALl the records

print("The isnerted records are")
data=cursor.execute('''Select * from STUDENT''')
for row in data:
    print(row)

## Commit your changes int he databse
connection.commit()
connection.close()
