---
title: Google Gemini Q A Chatbot
emoji: 🏢
colorFrom: blue
colorTo: blue
sdk: streamlit
sdk_version: 1.33.0
app_file: app.py
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
