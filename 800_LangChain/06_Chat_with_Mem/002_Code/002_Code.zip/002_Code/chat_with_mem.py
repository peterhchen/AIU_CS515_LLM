## Conversational Q&A Chatbot
import streamlit as st

from langchain.schema import HumanMessage, SystemMessage, AIMessage
#from langchain.chat_models import ChatOpenAI
from langchain_google_genai import ChatGoogleGenerativeAI

# Load all the environment variabels defined in .env:
# 1. GOOGLE_API_KEY and 
# 2. HUGGINGFACEHUB_API_KEY
from dotenv import load_dotenv
load_dotenv()

# Get the GOOGLE_API_KEY and HUGGINFACEHUB_API_TOKEN
import os
#os.environ["OPEN_API_KEY"]="sk-HBcNcxp8X8oAKhSGT3BlbkFJ9sHkCuOITYjONfcc0Y3p"
# openai_key=""
GOOGLE_API_KEY = "AIzaSyBcws3Gv_g0S26lzDM5n_fQ3h3gEBOoDYw"
os.environ["GOOGLE_API_KEY"]=GOOGLE_API_KEY
#os.environ["HUGGINGFACEHUB_API_TOKEN"]="hf_zjftfTRKFEebywxfIoyKUwepABtfGJS"
HUGGINGFACEHUB_API_KEY = "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"
os.environ["HUGGINGFACEHUB_API_TOKEN"] = HUGGINGFACEHUB_API_KEY

# llm = ChatGoogleGenerativeAI (model="gemini-pro", 
# google_api_key=GOOGLE_API_KEY,temperature=0.5)
chatllm = ChatGoogleGenerativeAI(model="gemini-pro", 
                                 convert_system_message_to_human=True,
                                 google_api_key=GOOGLE_API_KEY, 
                                 temperature=0.6)

# We use session_state to store the Human Question and AI Response.
if 'flowmessages' not in st.session_state:
    st.session_state['flowmessages'] = [
        SystemMessage(content="You are a comedian AI assistant")
    ]

def get_chatmodel_response (question):
    #response = chatllm.predict(question)
    #return response
    # We use schema for session_state
    st.session_state['flowmessages'].append(HumanMessage(content=question))
    #print("st.session_state['flowmessages']:")
    #print(st.session_state['flowmessages'])
    # https://js.langchain.com/docs/integrations/chat/google_generativeai
    answer=chatllm.invoke(st.session_state['flowmessages'])
    st.session_state['flowmessages'].append(AIMessage(content=answer.content))
    return answer.content


## streamlit GUI
#st.set_page_config (page_title="Q&A Demo")
st.set_page_config (page_title="Conversational Q&A Chatbot with Google ChatModel")
st.header("LangChain/Google ChatModel Application")

input = st.text_input("Input: ", key = "input")
submit = st.button("Ask the quesiton")

## If ask button is clicked
if submit:
    response = get_chatmodel_response(input)
    st.subheader("The Response is")
    st.write (response)
