## Integrate our code OpenAI API
import os
#from constants import openai_key
from constants import GOOGLE_API_KEY
#from langchain.llms import OpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
#from langchain import PromptTemplate
from langchain.chains import LLMChain

#from langchain.memory import ConversationBufferMemory

#from langchain.chains import SequentialChain
from langchain.chains import SimpleSequentialChain

import streamlit as st

os.environ["OOGLE_API_KEY"]=GOOGLE_API_KEY

# streamlit framework

st.title('Celebrity Search Results')
input_text=st.text_input("Search the topic u want")

# Prompt Templates

first_input_prompt=PromptTemplate(
    input_variables=['name'],
    template="Tell me about celebrity {name}"
)

# Memory

#person_memory = ConversationBufferMemory(input_key='name', memory_key='chat_history')
#dob_memory = ConversationBufferMemory(input_key='person', memory_key='chat_history')
#descr_memory = ConversationBufferMemory(input_key='dob', memory_key='description_history')

## OPENAI LLMS
#llm=OpenAI(temperature=0.8)
llm=ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=GOOGLE_API_KEY)
#chain=LLMChain(
#    llm=llm,prompt=first_input_prompt,verbose=True,output_key='person',memory=person_memory)
chain=LLMChain(
    llm=llm,prompt=first_input_prompt,verbose=True,output_key='person')

# Prompt Templates

second_input_prompt=PromptTemplate(
    input_variables=['person'],
    template="when was {person} born"
)

#chain2=LLMChain(
#    llm=llm,prompt=second_input_prompt,verbose=True,output_key='dob',memory=dob_memory)
# Prompt Templates

chain2=LLMChain(
    llm=llm,prompt=second_input_prompt,verbose=True,output_key='dob')
# Prompt Templates
#third_input_prompt=PromptTemplate(
#    input_variables=['dob'],
#    template="Mention 5 major events happened around {dob} in the world"
#)
#chain3=LLMChain(llm=llm,prompt=third_input_prompt,verbose=True,output_key='description',memory=descr_memory)
#parent_chain=SequentialChain(
#    chains=[chain,chain2,chain3],input_variables=['name'],output_variables=['person','dob','description'],verbose=True)
#parent_chain=SequentialChain(
#    chains=[chain,chain2],input_variables=['name'], output_variables=['person','dob'],verbose=True)
parent_chain=SimpleSequentialChain(
    chains=[chain,chain2], verbose=True)
if input_text:
    #st.write(parent_chain({'name':input_text}))
    #response = chain({'name':input_text})
    response = parent_chain.run(input_text)
    print("response:")
    print(response)
    #print("response['name']:")
    #print(response['name'])
    #print("response['person']:")
    #print(response['person'])
    #print("response['dob']:")
    #print(response['dob'])
    st.write(response)
    #with st.expander('Person Name'): 
    #    st.info(person_memory.buffer)

    #with st.expander('Major Events'): 
    #    st.info(descr_memory.buffer)
