## Integrate our code OpenAI API
import os
#from constants import openai_key
from constants import GOOGLE_API_KEY
#from langchain.llms import OpenAI
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

import streamlit as st

#os.environ["OPENAI_API_KEY"]=openai_key
os.environ["GOOGLE_API_KEY"]=GOOGLE_API_KEY
# streamlit framework

#st.title('Langchain Demo With OPENAI API')
st.title('Langchain Demo With Gemini API')
input_text=st.text_input("Search the topic u want")

## OPENAI LLMS
#llm=OpenAI(temperature=0.8)
## Google/Gemini LLMS
llm=ChatGoogleGenerativeAI(model="gemini-pro", google_api_key=GOOGLE_API_KEY)
#tweet_prompt = PromptTemplate.from_template("You are a content creator. Write me a tweet about {input_text}.")

#tweet_chain = LLMChain(llm=llm, prompt=tweet_prompt, verbose=True)


if input_text:
    #st.write(llm(input_text))
    #topic = "how ai is really cool"
    #resp = tweet_chain.run(topic=input_text)
    #print(resp)
    response = llm.invoke(input_text)
    st.write(response.content)

    
